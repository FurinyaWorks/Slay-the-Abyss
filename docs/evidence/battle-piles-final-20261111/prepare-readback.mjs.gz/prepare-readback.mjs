import fs from'node:fs';import path from'node:path';import assert from'node:assert/strict';import{pathToFileURL}from'node:url';import{createHash}from'node:crypto';
import{loadNativeUiEncoder}from'../../scripts/native-ui-encoder.mjs';import{embeddedScripts}from'../../scripts/native-script-inventory.mjs';
const root=process.cwd(),dir='build/pr588-pile-final-r12/3a928e26-af7f-4860-ac29-fd078371b0d5',out='.artifacts/battle-piles-final-20261111/candidate-r12',pinned=dir+'/readback',hash=b=>createHash('sha256').update(b).digest('hex');fs.mkdirSync(pinned,{recursive:true});fs.mkdirSync(out,{recursive:true});
const candidate=JSON.parse(fs.readFileSync(dir+'/candidate.json')),mapPath=candidate.candidate.path;assert.equal(hash(fs.readFileSync(mapPath)),candidate.candidate.sha256);
const tool='D:/MiliastraTools/genshin-miliastra-mcp',{native}=await loadNativeUiEncoder(tool),wire=await import(pathToFileURL(tool+'/src/scene/wire.mjs'));
const write=(n,v)=>fs.writeFileSync(pinned+'/'+n+'.json',JSON.stringify(v));
const scripts=embeddedScripts({mapPath,includeSource:true},wire);for(const s of scripts.scripts)assert.equal(hash(s.source),candidate.moduleDigests[s.name]);write('scripts',scripts);write('ui',native.getClientUi({mapPath,ui:'SlayTheAbyss'}));
for(const name of ['AbyssBattlePileCard','AbyssDeckCard','AbyssReadyCardImage','AbyssReadyCardGroup','AbyssMonsterActor','AbyssMonsterPower'])write(name,native.getClientUi({mapPath,template:name}));
write('readback-receipt',{ok:true,sourceCommit:candidate.sourceCommit,candidate:{sha256Before:candidate.candidate.sha256}});
let source=fs.readFileSync('.artifacts/pr588-visual-v6/readback-adapter.mjs','utf8');
source=source.replace(/const root=.*?out=.*?;/,`const root=${JSON.stringify(root)},out=${JSON.stringify(path.resolve(out))};`)
.replace(/const pinned=.*?;/,`const pinned=${JSON.stringify(path.resolve(pinned))};`)
.replace(/const candidatePath=.*?;/,`const candidatePath=${JSON.stringify(path.resolve(dir+'/candidate.json'))};`)
.replaceAll('templateRecords.length!==5','templateRecords.length!==6').replaceAll('.size!==5','.size!==6')
.replace(/inverse.scripts.length!==\d+/g,'inverse.scripts.length!==scripts.length').replace(/inverse.templates.length!==\d+/g,'inverse.templates.length!==templateRecords.length');
source=source.replace('imageType:spec.imageType??null',"imageType:spec.imageType??'Basic'");
source=source.replace('enableOutline:t.outline===true', 'enableOutline:t.outline!==false').replace("?'Pixels':'Percentage'","?'Pixel':'Percentage'");fs.writeFileSync(out+'/adapter.mjs',source);await import(pathToFileURL(path.resolve(out+'/adapter.mjs')));
