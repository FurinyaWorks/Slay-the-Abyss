from PIL import Image,ImageDraw
from pathlib import Path
import hashlib,json
root=Path('.artifacts/pile-final-visual-1794375825480');frames=Path('.artifacts/pile-final-visual-1794379150422');out=Path('.artifacts/battle-piles-final-20261111');h=lambda b:hashlib.sha256(b).hexdigest()
rows=[]
for p in sorted(root.glob('*.png')):
 im=Image.open(p).convert('RGBA'); r={'file':str(p),'sha256':h(p.read_bytes()),'size':list(im.size)}
 if p.stem in ['00-empty-draw','04-exhaust-offering','05-discard-strike','06-draw-next-turn','07-pile-sort-default-restored','08-card-detail-heading','09-return-to-pile']:
  roi=im.crop((0,570,180,624));r['returnRgbaSha256']=h(roi.tobytes());r['returnGoldPixels']=sum(r>95 and g>70 and b<175 and r>g and a>150 for r,g,b,a in roi.get_flattened_data())
 if p.stem in ['06-draw-next-turn','07-pile-sort-default-restored','09-return-to-pile']:
  r['fourCardGridRgbaSha256']=h(im.crop((180,180,920,425)).tobytes())
 rows.append(r)
roi=[r['returnRgbaSha256']for r in rows if 'returnRgbaSha256'in r];assert len(roi)==7 and len(set(roi))==1
hashes=[h(p.read_bytes())for p in sorted(frames.glob('mask-frame-*.png'))];assert len(hashes)==10 and len(set(hashes))==1
proof={'kind':'raw-original-png-pixel-identity-counterevidence','candidate':'3a928e26-af7f-4860-ac29-fd078371b0d5','originalRendererSha256':'5971287fabb54d2c061b76857bafffae6575b9e7612cb4bcc4ba95e88bb0aa20','shots':rows,'sameReturnPixelsAcrossSevenViews':True,'tenConsecutiveOriginalRendererPngs':hashes,'tenConsecutiveIdentical':True,'note':'Original saved PNGs contain the same complete return pixels. Earlier visual-tool repeated-image display was misinterpreted as missing render content. Experimental renderer patches are rejected; no claim based on altered renderer.'}
(out/'visual-pixel-check.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
for index,names in enumerate([['00-empty-draw','04-exhaust-offering','05-discard-strike','06-draw-next-turn','08-card-detail-heading','09-return-to-pile'],['01-whole','00-relic-detail','00-relic-next','02-defend-hover','03-bash-centred-aim','04a-exhaust-entry-live']]):
 sheet=Image.new('RGB',(1536,1368),'#dddddd');draw=ImageDraw.Draw(sheet)
 for i,name in enumerate(names):
  x=(i%2)*768;y=(i//2)*456;im=Image.open(root/(name+'.png')).convert('RGB').resize((768,432));sheet.paste(im,(x,y+24));draw.text((x+8,y+5),name,fill='black')
 sheet.save(out/f'inspection-sheet-{index}.png')
print(json.dumps({'shots':len(rows),'returnViews':len(roi),'returnPixelHashesEqual':True,'tenRepeatedHashesEqual':True}))
