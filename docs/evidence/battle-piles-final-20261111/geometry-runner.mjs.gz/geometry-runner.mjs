import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
const dir='.artifacts/battle-piles-final-20261111/candidate-r12';
const savePath=dir+'/hud.save.json', sdkPath='F:/New folder/.worktrees/ui-lifecycle/.artifacts/task-100-1/final/v25/sdk-harness/sdk-export-only/actual-session.mjs';
const raw=fs.readFileSync(savePath),save=JSON.parse(raw),hash=b=>createHash('sha256').update(b).digest('hex');
const {Gr,dn,wi,pa,Me,d}=await import(pathToFileURL(sdkPath));
const enc=s=>new TextEncoder().encode(s);let session;
function value(L,index){const type=d.lua_type(L,index);if(type===0)return null;if(type===3)return d.lua_tonumber(L,index);if(type===4)return Buffer.from(d.lua_tolstring(L,index)).toString();if(type===1)return d.lua_toboolean(L,index);if(type!==5)return '<'+type+'>';const r={},at=d.lua_absindex(L,index);d.lua_pushnil(L);while(d.lua_next(L,at)){r[value(L,-2)]=value(L,-1);d.lua_pop(L,1)}return r;}
try{
 session=Gr(save.assets.server,{templatesProject:save.assets.client,scripts:save.assets.scripts,serverConfig:save.serverLogic,canvasId:'pc-16-9',language:'LanguageChs'});
 const script=session.runtime.mountedScripts.find(s=>/abyss_ui(?:\.lua)?$/.test(s.path));assert(script?.alive);const L=script.env,top=d.lua_gettop(L);d.lua_getglobal(L,enc('OnUpdate'));let found=false;for(let i=1;i<50;i++){const n=d.lua_getupvalue(L,-1,i);if(!n)break;if(Buffer.from(n).toString()==='view'){d.lua_setglobal(L,enc('__GEOMETRY_VIEW'));found=true;break}d.lua_pop(L,1)}d.lua_settop(L,top);assert(found);
 for(let i=0;i<120;i++)dn(session,1/60);
 session.runtime.runChunk(L,'function __GEOMETRY_STATE() local c=__GEOMETRY_VIEW.run.combat;local h={};for i,x in ipairs(c.hand)do h[i]={slot=i,uid=x.uid,id=x.cardId}end;return {hand=h,potions=__GEOMETRY_VIEW.run.potions,enemyCount=#c.enemies} end','READ_ONLY_GEOMETRY');d.lua_getglobal(L,enc('__GEOMETRY_STATE'));assert.equal(d.lua_pcall(L,0,1,0),0);const hand=value(L,-1);d.lua_settop(L,top);
 const boxes=wi(session),matrices=pa(session,boxes),all=[];
 function visit(n,p,active){const path=p?p+'/'+n.name:n.name,visible=active&&n.visible!==false;const b=boxes.get(n.Id),m=matrices.get(n.Id);if(b&&m){const pt=Me(m,b.centerX,b.centerY);all.push({path,id:n.Id,visible,ownVisible:n.visible!==false,sdkPointer:{x:pt.x,y:pt.y},canvasTopLeft:{x:pt.x,y:900-pt.y},size:{width:b.width,height:b.height}})}for(const c of n.children??[])visit(c,path,visible)}
 for(const root of session.runtime.roots)visit(root,'',true);
 const exact=suffix=>{const a=all.filter(n=>n.path.endsWith('/'+suffix));assert.equal(a.length,1,suffix);return a[0]};
 assert.equal(Object.keys(hand.potions).length,3,'3-potion HUD required');assert.equal(hand.enemyCount,2);assert.equal(Object.keys(hand.hand).length,10);const cards=Object.values(hand.hand).map(x=>({...x,box:exact('stage/battlePanel/card'+x.slot),hit:exact('stage/battlePanel/card'+x.slot+'/hit')}));
 const buttons=all.filter(n=>/stage\//.test(n.path)&&/(?:draw|discard|exhaust|deck|close|relic|potion|playArea)/i.test(n.path)&&!/(?:card\d+|\/label|\/text|\/icon|\/art|\/body|\/title|\/cost|\/badge|\/hover|\/pressed|\/disabled|\/normal)(?:\/|$)/i.test(n.path));
 const report={kind:'actual-sdk-initial-hud-geometry',saveSha256:hash(raw),sdkSha256:hash(fs.readFileSync(sdkPath)),buildId:JSON.parse(fs.readFileSync(dir+'/adapter-receipt.json')).buildId,canvas:{width:1600,height:900},coordinateNotes:'sdkPointer is SDK vi input with bottom-left origin; canvasTopLeft flips Y for a 1600x900 browser canvas. Hidden controls are geometry only; not clickable until their ancestor modal opens.',steps:120,pointerCommands:0,sourceInjected:false,potions:hand.potions,enemyCount:hand.enemyCount,cards,info:all.filter(n=>/stage\/battlePanel\/statusInfo(?:$|\/(?:title|summary|tag|rule|name[0-9]+|text[0-9]+)$)/.test(n.path)),offering:cards.filter(c=>c.id==='offering'),feedback:all.filter(n=>/feedback\/playedCard/.test(n.path)),actors:all.filter(n=>/stage\/battlePanel\/actorLayer\/[^/]+\/hit$/.test(n.path)),buttons,faults:session.runtime.logs.filter(l=>l.level==='lua-error'||/ABYSS_UI failed/.test(l.text)),ready:session.runtime.logs.some(l=>l.text==='ABYSS_UI ready')};
 fs.writeFileSync('.artifacts/battle-repair-20261111/input-cadence/geometry-pile-final.json',JSON.stringify(report,null,2),{flag:'w'});console.log(JSON.stringify({ready:report.ready,faults:report.faults,offering:report.offering,buttons:buttons.filter(n=>/playArea|potion[1-5]$/.test(n.path))},null,2));
}finally{for(const runtime of session?.runtimes??[])try{runtime.destroy()}catch{}}


