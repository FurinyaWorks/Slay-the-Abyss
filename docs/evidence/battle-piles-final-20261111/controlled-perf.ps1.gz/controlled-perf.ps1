$ErrorActionPreference = 'Stop'
$evidenceRoot = '.artifacts/battle-piles-final-20261111'
$serviceFile = "$evidenceRoot/service-final-visual/service.json"
$initialService = Get-Content -LiteralPath $serviceFile -Raw | ConvertFrom-Json
$liveService = Get-CimInstance Win32_Process -Filter "ProcessId=$($initialService.pid)"
if ($liveService.CommandLine -notlike '*battle-stage-review/serve.mjs*service-final-visual*') { throw 'Unexpected initial service identity' }
Stop-Process -Id $initialService.pid
$rounds = @('baseline-1','current-1','current-2','baseline-2')
foreach ($round in $rounds) {
  $reviewOutput = "$evidenceRoot/service-controlled-$round"
  $proc = Start-Process -FilePath 'C:\Program Files\nodejs\node.exe' -ArgumentList @('experiments/battle-stage-review/serve.mjs','--scenario-dir',"$evidenceRoot/candidate-r12",'--output',$reviewOutput,'--candidate','build/pr588-pile-final-r12/3a928e26-af7f-4860-ac29-fd078371b0d5/candidate.json','--port','52608') -WindowStyle Hidden -PassThru -RedirectStandardOutput "$evidenceRoot/server-$round.log" -RedirectStandardError "$evidenceRoot/server-$round.err"
  $deadline = [DateTime]::UtcNow.AddSeconds(60)
  while (!(Test-Path -LiteralPath "$reviewOutput/service.json")) {
    if ($proc.HasExited -or [DateTime]::UtcNow -gt $deadline) { throw "Service startup failed: $round" }
    Start-Sleep -Milliseconds 300
  }
  Copy-Item -LiteralPath "$reviewOutput/service.json" -Destination "$evidenceRoot/controlled-service.json"
  Copy-Item -LiteralPath '.artifacts/battle-repair-20261111/source-aim-candidate/hud.save.json' -Destination "$reviewOutput/workspace/baseline-97.save.json"
  Get-CimInstance Win32_OperatingSystem | Select-Object FreePhysicalMemory,TotalVisibleMemorySize | ConvertTo-Json | Set-Content "$evidenceRoot/memory-$round.json"
  $runner = if ($round -like 'baseline*') { "$evidenceRoot/baseline-controlled.mjs" } else { "$evidenceRoot/browser-controlled.mjs" }
  node $runner > "$evidenceRoot/controlled-$round.log" 2>&1
  if ($LASTEXITCODE -ne 0) { throw "Browser check failed: $round" }
  $verified = Get-CimInstance Win32_Process -Filter "ProcessId=$($proc.Id)"
  if ($verified.CommandLine -notlike "*battle-stage-review/serve.mjs*service-controlled-$round*") { throw 'Service identity changed' }
  Stop-Process -Id $proc.Id
}
Start-Process -FilePath 'C:\Program Files\nodejs\node.exe' -ArgumentList @('experiments/battle-stage-review/serve.mjs','--scenario-dir',"$evidenceRoot/candidate-r12",'--output',"$evidenceRoot/service-final",'--candidate','build/pr588-pile-final-r12/3a928e26-af7f-4860-ac29-fd078371b0d5/candidate.json','--port','52608') -WindowStyle Hidden -RedirectStandardOutput "$evidenceRoot/server-final.log" -RedirectStandardError "$evidenceRoot/server-final.err"
