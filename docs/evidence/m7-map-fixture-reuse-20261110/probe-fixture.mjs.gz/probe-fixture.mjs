import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
const hash=x=>createHash('sha256').update(x).digest('hex');
const root=process.cwd();
const helper=readFileSync('tests/helpers/map-emerald-vm.mjs','utf8')
.replace("'./lua-graph-observer.mjs'",JSON.stringify(pathToFileURL(root+'/tests/helpers/lua-graph-observer.mjs').href))
.replace("'../../scripts/build-lua-data.mjs'",JSON.stringify(pathToFileURL(root+'/scripts/build-lua-data.mjs').href))
.replace('createRequire(import.meta.url)',`createRequire(${JSON.stringify(pathToFileURL(root+'/tests/helpers/map-emerald-vm.mjs').href)})`)
.replace('{integration=true}={}',"{integration=true,fixture='tests/helpers/map-emerald-cases.lua'}={}")
.replace("dofile('tests/helpers/map-emerald-cases.lua')",'dofile(${luaString(fixture)})');
const {mapEmeraldVm,mapEmeraldBefore}=await import('data:text/javascript,'+encodeURIComponent(helper));
const current=readFileSync('src/lua/abyss_map.lua','utf8');
const test=readFileSync('tests/emerald-map.test.mjs','utf8');
const list=test.slice(test.indexOf('const mutations=')+'const mutations='.length,test.indexOf('\n  for(const [name,from,to]'));
const mutations=Function('return '+list)();
const cases=[['current',current,true],['before',mapEmeraldBefore(),true],['before-negative',mapEmeraldBefore(),false],...mutations.map(([name,from,to])=>{assert.ok(current.includes(from));return [name,current.replace(from,to),false]})];
const rows=[];
for(const [i,[name,source,integration]]of cases.entries()){
 const old='.artifacts/round24/map-emerald-cases-before.lua',after='tests/helpers/map-emerald-cases.lua';
 const result={name,integration,sourceSha256:hash(source)},streams=[];
 // Alternate first execution to avoid always attributing same-process warmup to one candidate.
 for(const fixture of i%2?[after,old]:[old,after]){
  const start=performance.now();const graphs=mapEmeraldVm(source,{integration,fixture});const ms=performance.now()-start;
  const text=JSON.stringify(graphs);streams.push(text);result[fixture===old?'before':'after']={ms,graphs:graphs.length,bytes:Buffer.byteLength(text),sha256:hash(text)};
 }
 assert.equal(streams[0],streams[1],name+' complete graph stream');rows.push(result);console.log(JSON.stringify(result));
}
writeFileSync('.artifacts/round24/fixture-comparison.json',JSON.stringify({helperSha256:hash(helper),beforeFixtureSha256:hash(readFileSync('.artifacts/round24/map-emerald-cases-before.lua')),afterFixtureSha256:hash(readFileSync('tests/helpers/map-emerald-cases.lua')),rows},null,2)+'\n');
