import subprocess,time,json,pathlib,hashlib,gzip,sys
root=pathlib.Path.cwd();out=root/'.artifacts/round24'; rows=[]
tracked=subprocess.check_output(['git','ls-files','-z']).decode().split('\0');tracked=[p for p in tracked if p]
extra=['tests/helpers/map-emerald-fixture-contract.mjs','tests/helpers/map-emerald-fixture-source-inverse.mjs','tests/fixtures/map-emerald-cases-before-reuse.lua']
files=sorted(set(tracked+extra+[str(p.relative_to(root)) for p in (root/'build/lua').rglob('*') if p.is_file()]))
def sha(b):return hashlib.sha256(b).hexdigest()
def snapshot(name):
 value={p:sha((root/p).read_bytes()) if (root/p).is_file() else None for p in files};b=(json.dumps(value,sort_keys=True,separators=(',',':'))+'\n').encode();path=out/(name+'.json.gz');path.write_bytes(gzip.compress(b,mtime=0));return value,{'path':str(path.relative_to(root)),'sha256':sha(path.read_bytes()),'uncompressedSha256':sha(b),'files':len(value)}
for name in ['emerald-map','ci-complete-calibration']:
 file='tests/'+name+'.test.mjs';pre,before=snapshot(name+'-before');start=time.perf_counter();command=['node','--test','--test-concurrency=1','--test-reporter=spec','--test-reporter-destination=stdout','--test-reporter=./scripts/ci-timing-reporter.mjs','--test-reporter-destination='+str(out/(name+'.jsonl')),file]
 log=out/(name+'.log')
 with log.open('wb') as f:result=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
 wall=(time.perf_counter()-start)*1000;post,after=snapshot(name+'-after');text=log.read_text();summary={}
 for line in text.splitlines():
  if line.startswith('ℹ '):
   parts=line[2:].split(' ')
   if len(parts)==2 and parts[0] in ['tests','pass','fail','cancelled','skipped','duration_ms']:summary[parts[0]]=float(parts[1])
 row={'testFile':file,'command':command,'returncode':result.returncode,'processWallMs':wall,'summary':summary,'log':{'path':str(log.relative_to(root)),'sha256':sha(log.read_bytes())},'before':before,'after':after,'inputsMatched':pre==post,'changedInputs':[p for p in files if pre[p]!=post[p]],'native':(out/(name+'.jsonl')).read_text()}
 rows.append(row);(out/'targeted-validation.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 if result.returncode or pre!=post:sys.exit(1)
