import {writeFileSync} from 'node:fs';
import assert from 'node:assert/strict';
const root='/workspace/scratch/c1a4970a76e0/';
async function snapshot(path){
 const {gameLayout}=await import(path+'/scripts/game-ui-layout.mjs');
 const {nativeTheme}=await import(path+'/scripts/native-ui-theme.mjs');
 const {officialAssetsTheme,applyOfficialAssets}=await import(path+'/scripts/official-assets-layout.mjs');
 const theme=officialAssetsTheme(nativeTheme),official=gameLayout(theme);
 applyOfficialAssets([official],theme);
 return {native:gameLayout(),official};
}
const base=await snapshot(root+'m7-pile-contrast-evidence/review-base'),repair=await snapshot(root+'m7-pile-contrast-repair');
const differences=[];
function diff(a,b,path='$'){
 if(Object.is(a,b))return;
 if(a&&b&&typeof a==='object'&&typeof b==='object'){
  assert.deepEqual(Object.keys(a),Object.keys(b),path+' keys');
  for(const k of Object.keys(a))diff(a[k],b[k],path+'.'+k);
 }else differences.push({path,before:a,after:b});
}
diff(base,repair);
assert.equal(differences.length,5);
for(const d of differences){assert.ok(d.path.endsWith('.text.colour'));assert.equal(d.before,'#E0BC73');assert.equal(d.after,'#FFF8E7');}
writeFileSync(root+'m7-pile-contrast-evidence/independent-structure-diff.json',JSON.stringify(differences,null,2)+'\n');
console.log(JSON.stringify(differences,null,2));
