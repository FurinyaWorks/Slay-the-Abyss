import os, subprocess, hashlib, json, pathlib, time
root=pathlib.Path('/workspace/scratch/c1a4970a76e0/m7-pile-contrast-repair');out=root.parent/'m7-pile-contrast-evidence';os.chdir(root)
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def snapshot():
 names=subprocess.check_output(['git','ls-files','-z']).decode().split('\0')
 names += [str(p.relative_to(root)) for p in (root/'build').rglob('*') if p.is_file()]
 names += [str(p) for p in (root/'node_modules').resolve().rglob('*') if p.is_file()]
 names += [str(pathlib.Path(subprocess.check_output(['which','node']).decode().strip()).resolve()),str(out/'validate.py')]
 return {p:sha(p) if pathlib.Path(p).is_file() else None for p in sorted(set(names)) if p}
before=snapshot();(out/'inputs-before.json').write_text(json.dumps(before,ensure_ascii=False,indent=2)+'\n')
commands=[('behavior',['node','--test','--test-concurrency=1','tests/mobile-typography.test.mjs','tests/official-battle-pile-layout.test.mjs','tests/official-assets.test.mjs']),('syntax',['npm','run','check:syntax']),('guidance',['npm','run','check:guidance']),('backlog',['npm','run','verify:backlog']),('network',['npm','run','check:network']),('diff',['git','diff','--check'])]
rows=[]
for name,cmd in commands:
 start=time.time()
 with (out/(name+'.log')).open('wb') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 row=dict(name=name,command=cmd,exitCode=r.returncode,elapsedSeconds=time.time()-start,logSha256=sha(out/(name+'.log')));rows.append(row);print(json.dumps(row),flush=True)
after=snapshot();(out/'inputs-after.json').write_text(json.dumps(after,ensure_ascii=False,indent=2)+'\n')
report=dict(commands=rows,snapshotItems=len(before),materializedItems=sum(v is not None for v in before.values()),inputChanges=[p for p in sorted(set(before)|set(after)) if before.get(p)!=after.get(p)])
(out/'validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report),flush=True)
