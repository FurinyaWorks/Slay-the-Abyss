// Uses the same exported SDK and pointer/step helpers as PR #582's actual-GIL
// probe. SDK CPU costs are deliberately separate from renderer/device FPS.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
const [savePath,sdkPath,output]=process.argv.slice(2);
if(!savePath||!sdkPath||!output||fs.existsSync(output))throw Error('Usage: node scripts/measure-official-battle.mjs <fixture.save.json> <existing SDK export.mjs> <new report.json>');
const hash=p=>createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const sdkSha256=hash(sdkPath);
const {Gr,vi,dn,wi,pa,Me,d}=await import(pathToFileURL(path.resolve(sdkPath)));
const parseStart=performance.now(),saveBytes=fs.readFileSync(savePath),save=JSON.parse(saveBytes),parseMs=performance.now()-parseStart;
const fixtureReceiptPath=savePath+'.receipt.json',fixtureReceipt=JSON.parse(fs.readFileSync(fixtureReceiptPath,'utf8'));
assert.equal(fixtureReceipt.kind,'offline-sdk-pressure-fixture');assert.equal(hash(fixtureReceipt.input),fixtureReceipt.inputSha256);
const modified=save.assets.scripts.find(s=>s.path.endsWith(fixtureReceipt.modifiedModule));assert.equal(createHash('sha256').update(modified.source).digest('hex'),fixtureReceipt.fixtureModuleSha256);
const report={kind:'sdk-battle-page-fixture',measurementScope:'offline-fixture-with-injected-gameui',actualGilLuaExact:false,fixtureReceipt,fixtureReceiptSha256:hash(fixtureReceiptPath),deviceVerified:false,gpuFpsMeasured:false,node:process.version,save:path.resolve(savePath),saveSha256:createHash('sha256').update(saveBytes).digest('hex'),sdkSha256,parseMs,stages:[],status:'running'};
let session,L,rootScript;
const enc=s=>new TextEncoder().encode(s);
function expose(fn,key,name){const top=d.lua_gettop(L);d.lua_getglobal(L,enc(fn));let found=false;for(let i=1;i<50;i++){const k=d.lua_getupvalue(L,-1,i);if(!k)break;if(Buffer.from(k).toString()===key){d.lua_setglobal(L,enc(name));found=true;break}d.lua_pop(L,1)}d.lua_settop(L,top);assert(found,'missing actual-script upvalue '+key)}
function luaValue(index,depth=0){assert(depth<12);const type=d.lua_type(L,index);if(type===0)return null;if(type===1)return d.lua_toboolean(L,index);if(type===3)return d.lua_tonumber(L,index);if(type===4)return Buffer.from(d.lua_tolstring(L,index)).toString();if(type!==5)return '<type-'+type+'>';const result={},abs=d.lua_absindex(L,index);d.lua_pushnil(L);while(d.lua_next(L,abs)!==0){const key=luaValue(-2,depth+1);result[key]=luaValue(-1,depth+1);d.lua_pop(L,1)}return result}
function status(){const top=d.lua_gettop(L);d.lua_getglobal(L,enc('__BATTLE_STATUS'));assert.equal(d.lua_pcall(L,0,1,0),0,'status query failed');const value=luaValue(-1);d.lua_settop(L,top);return value}
function native(p){let n=session.runtime.roots[0];for(const name of p.split('/')){const a=n.children.filter(c=>c.name===name);assert.equal(a.length,1,'native path '+p);n=a[0]}return n}
function point(p){const n=native(p),boxes=wi(session),box=boxes.get(n.Id),matrix=pa(session,boxes).get(n.Id);assert(box&&matrix);return Me(matrix,box.centerX,box.centerY)}
const stepTimes=[],pointerEvents=[];
function step(){const t=performance.now();dn(session,1/60);stepTimes.push(performance.now()-t)}
function pointer(type,p){
 const started=performance.now();
 try{return vi(session,type,p.x,p.y)}
 finally{pointerEvents.push({type,x:p.x,y:p.y,elapsedMs:performance.now()-started});}
}
function tap(p){const xy=typeof p==='string'?point(p):p;pointer('move',xy);pointer('down',xy);step();pointer('up',xy);step()}
function drain(){for(let i=0;i<600;i++){const s=status();if(!s.busy)return s;step()}throw Error('feedback did not settle')}
function timing(values){const sorted=[...values].sort((a,b)=>a-b),q=p=>sorted[Math.max(0,Math.ceil(sorted.length*p)-1)];return {samples:sorted.length,p50:q(.5),p95:q(.95),p99:q(.99),max:sorted.at(-1)}}
function stage(name,fn){
 const before=session?.runtime.controlsById.size??0,t=performance.now(),at=stepTimes.length,inputAt=pointerEvents.length;
 const result=fn(),inputs=pointerEvents.slice(inputAt);
 report.stages.push({name,elapsedMs:performance.now()-t,controlsBefore:before,controlsAfter:session?.runtime.controlsById.size??0,
  steps:stepTimes.length-at,sdkStepMs:timing(stepTimes.slice(at)),pointerEvents:inputs,
  pointerHandlerMs:timing(inputs.map(event=>event.elapsedMs)),memory:process.memoryUsage(),state:result});
 return result;
}
try{
 stage('cold-initialize',()=>{
  session=Gr(save.assets.server,{templatesProject:save.assets.client,scripts:save.assets.scripts,serverConfig:save.serverLogic,canvasId:'pc-16-9',language:'LanguageChs'});
  rootScript=session.runtime.mountedScripts.find(s=>/abyss_ui(?:\.lua)?$/.test(s.path));assert(rootScript?.alive);L=rootScript.env;expose('OnUpdate','view','__BATTLE_VIEW');expose('OnDestroy','portraits','__BATTLE_PORTRAITS');
  session.runtime.runChunk(L,`function __BATTLE_STATUS()
   local v=__BATTLE_VIEW;local c=v.run and v.run.combat;local cards,enemies={},{}
   if c then
    local C=require('abyss_combat')
    for i,card in ipairs(c.hand)do local def=C.cardDefinition(c,card);local plain=C.canPlay(c,card.uid,nil);local target=C.canPlay(c,card.uid,1);cards[i]={uid=card.uid,id=card.cardId,type=def.type,plain=plain,target=target}end
    for i,e in ipairs(c.enemies)do local g=require('abyss_battle_enemy_view').geometry(e);enemies[i]={hp=e.hp,x=g.hitX,y=g.hitY}end
   end
   local discard,pile={},{}
   for _,card in ipairs(c and c.discard or {})do discard[#discard+1]=card.uid end
   for _,card in ipairs(v.deckUI.cards or {})do pile[#pile+1]=card.uid end
   return {phase=v.run and v.run.phase,mode=v.mode,hand=c and #c.hand,energy=c and c.energy,turn=c and c.turn,busy=v.battleUI.busy,selected=v.battleUI.selected,dragging=v.battleUI.gesture and v.battleUI.gesture.moving==true,heldUid=v.battleUI.gesture and v.battleUI.gesture.uid,cards=cards,enemies=enemies,deckOpen=v.deckUI.visible,pileKind=v.deckUI.pileKind,discard=discard,pile=pile,routeOpen=v.routeOpen==true,portraits=__BATTLE_PORTRAITS:status()}
  end`,'READ_ONLY_BATTLE_STATUS');
  assert(session.runtime.logs.some(l=>l.text==='ABYSS_UI ready'));return status();
 });
 stage('portrait-ready-feedback-idle',()=>{for(let i=0;i<600;i++){const s=status();if(s.portraits.battle?.phase==='ready'&&!s.busy)return s;step()}throw Error('battle portrait never became ready')});
 stage('opening-hand-layout-settle-120-steps',()=>{for(let i=0;i<120;i++)step();return status()});
 stage('two-seconds-card-glow-and-held-aim',()=>{
  const before=status(),entry=Object.entries(before.cards).find(([,c])=>c.type==='attack'&&c.target);assert(entry,'no legal attack to aim');
  const card=point('stage/battlePanel/card'+entry[0]+'/hit');
  pointer('move',card);pointer('down',card);step();
  const enemy=Object.values(before.enemies)[0];assert(enemy);
  const actor=native('stage/battlePanel/actorLayer').children.find(a=>a.visible&&a.children.some(c=>c.name==='hit'));
  const hit=actor.children.find(c=>c.name==='hit'),boxes=wi(session),box=boxes.get(hit.Id),matrix=pa(session,boxes).get(hit.Id);
  const target=Me(matrix,box.centerX,box.centerY);
  pointer('move',target);for(let i=0;i<120;i++)step();
  const held=status();assert(held.dragging&&held.heldUid===entry[1].uid,'targeted attack did not remain held');
  pointer('move',card);pointer('up',card);step();
  const after=drain();assert.equal(after.hand,before.hand);assert.equal(after.energy,before.energy);
  return {before,held,after};
 });
 stage('steady-120-frames',()=>{for(let i=0;i<120;i++)step();return status()});
 stage('actual-idle-native-call-census',()=>{
  session.runtime.runChunk(L,`__IDLE_WRITES=0;__IDLE_PAINTS=0;__IDLE_CREATES=0
   local idle=require('abyss_lumine_idle');local paint=idle.paint
   idle.paint=function(data,pages,clock,enabled,write)
    __IDLE_PAINTS=__IDLE_PAINTS+1
    return paint(data,pages,clock,enabled,function(...)__IDLE_WRITES=__IDLE_WRITES+1;return write(...)end)
   end
   local create=game.InstantiateClientUIControl
   game.InstantiateClientUIControl=function(...)__IDLE_CREATES=__IDLE_CREATES+1;return create(...)end
   function __IDLE_COUNTS()return {writes=__IDLE_WRITES,paints=__IDLE_PAINTS,creates=__IDLE_CREATES}end`,'CALL_CENSUS_ONLY');
  const count=session.runtime.controlsById.size;for(let i=0;i<120;i++)step();assert.equal(session.runtime.controlsById.size,count);
  const top=d.lua_gettop(L);d.lua_getglobal(L,enc('__IDLE_COUNTS'));assert.equal(d.lua_pcall(L,0,1,0),0);
  const counts=luaValue(-1);d.lua_settop(L,top);assert.equal(counts.creates,0);return counts;
 });
 stage('engine-root-cleanup',()=>{for(const runtime of session.runtimes)for(const root of [...runtime.roots])runtime.destroyControl(root);assert.equal(session.runtime.controlsById.size,0);assert.equal(rootScript.alive,false);return {liveControls:0}});
 report.status='passed';
}catch(error){report.status='failed';report.error=String(error.stack);process.exitCode=1}
finally{
 report.logs=session?.runtime.logs??[];report.faults=report.logs.filter(l=>l.level==='lua-error'||/ABYSS_UI failed|prepare_failed|command_failed/.test(l.text));if(report.faults.length){report.status='failed';process.exitCode=1}
 report.sdkStepMs=timing(stepTimes);
 report.pointerEvents=pointerEvents;
 report.pointerHandlerMs=timing(pointerEvents.map(event=>event.elapsedMs));
 report.sourceStable=hash(savePath)===report.saveSha256&&hash(sdkPath)===sdkSha256&&hash(fixtureReceiptPath)===report.fixtureReceiptSha256;
 if(!report.sourceStable){report.status='failed';report.error='Measurement inputs changed';process.exitCode=1}for(const runtime of session?.runtimes??[])try{runtime.destroy()}catch{}
 fs.writeFileSync(output,JSON.stringify(report,null,2));console.log(JSON.stringify({status:report.status,error:report.error,stages:report.stages.map(s=>({name:s.name,elapsedMs:s.elapsedMs,controls:s.controlsAfter})),sdkStepMs:report.sdkStepMs,faults:report.faults.length}));
}
