import subprocess,time,json,pathlib,hashlib,gzip,sys,datetime
root=pathlib.Path.cwd();out=root/'.artifacts/round25';rows=[]
fixture=root/'tests/helpers/map-emerald-cases.lua'; current=fixture.read_bytes();old=(root/'tests/fixtures/map-emerald-cases-before-reuse.lua').read_bytes()
tracked=[p for p in subprocess.check_output(['git','ls-files','-z']).decode().split('\0') if p]+[str(p) for pattern in ['tests/helpers/map-optimized-cost-*','tests/fixtures/map-optimized-cost-*','docs/evidence/m7-map-optimized-cost-20261110/*'] for p in root.glob(pattern) if p.is_file()]
files=sorted(set(tracked+[str(p.relative_to(root)) for p in (root/'build/lua').rglob('*') if p.is_file()]))
files=sorted(set(files+[str(p) for p in pathlib.Path('node_modules').rglob('*') if p.is_file()]+[str(p) for p in pathlib.Path('build/tools').rglob('*') if p.is_file()]))
node_path=pathlib.Path(subprocess.check_output(['which','node']).decode().strip()).resolve()
(out/'validation-environment.json').write_text(json.dumps({'nodeVersion':subprocess.check_output(['node','--version']).decode().strip(),'nodeExecutable':str(node_path),'nodeExecutableSha256':hashlib.sha256(node_path.read_bytes()).hexdigest(),'platform':sys.platform,'dependencyFiles':sum(p.startswith('node_modules/') for p in files),'scope':'Installed dependency bytes and pinned tool bytes included in before/after snapshots for optimized-dependency-bound only; previous pair did not capture installed bytes.'},indent=2)+'\n')
def sha(b):return hashlib.sha256(b).hexdigest()
def snap(name):
 value={p:sha((root/p).read_bytes()) if (root/p).is_file() else None for p in files};b=(json.dumps(value,sort_keys=True,separators=(',',':'))+'\n').encode();path=out/(name+'.json.gz');path.write_bytes(gzip.compress(b,mtime=0));return value,{'path':str(path.relative_to(root)),'sha256':sha(path.read_bytes()),'uncompressedSha256':sha(b),'files':len(value)}
try:
 for name in ['ci-complete-calibration']:
  data=current; file='tests/'+name+'.test.mjs';pre,before=snap(name+'-final-before');start=time.perf_counter();started=datetime.datetime.now(datetime.timezone.utc).isoformat();command=['node','--test','--test-concurrency=1','--test-reporter=spec','--test-reporter-destination=stdout','--test-reporter=./scripts/ci-timing-reporter.mjs','--test-reporter-destination='+str(out/(name+'-final.jsonl')),file]
  log=out/(name+'-final.log');error=None
  with log.open('wb') as f:
   try:result=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,timeout=240);code=result.returncode
   except subprocess.TimeoutExpired:code=None;error='timeout'
  wall=(time.perf_counter()-start)*1000;post,after=snap(name+'-final-after');text=log.read_text();summary={}
  for line in text.splitlines():
   if line.startswith('ℹ '):
    parts=line[2:].split(' ')
    if len(parts)==2 and parts[0] in ['tests','pass','fail','cancelled','skipped','duration_ms']:summary[parts[0]]=float(parts[1])
  row={'name':name,'sourceCommit':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'fixtureSha256':sha(data),'startedAt':started,'testFile':file,'command':command,'returncode':code,'error':error,'processWallMs':wall,'summary':summary,'log':{'path':str(log.relative_to(root)),'sha256':sha(log.read_bytes())},'before':before,'after':after,'inputsMatched':pre==post,'changedInputs':[p for p in files if pre[p]!=post[p]],'native':(out/(name+'-final.jsonl')).read_text() if (out/(name+'-final.jsonl')).exists() else None}
  rows.append(row);(out/'final-calibration-validation.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps({k:v for k,v in row.items() if k not in ['native','command']}),flush=True)
  if code or error or pre!=post:sys.exit(1)
finally:fixture.write_bytes(current)
