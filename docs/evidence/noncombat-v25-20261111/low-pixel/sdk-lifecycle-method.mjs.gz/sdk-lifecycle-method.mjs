import fs from 'node:fs';import assert from 'node:assert/strict';import {pathToFileURL} from 'node:url';import {createHash} from 'node:crypto';
const savePath='.artifacts/noncombat-low-pixel/r7-preview/pr588.actual.save.json';
const sdkPath='F:/New folder/.worktrees/ui-lifecycle/.artifacts/task-100-1/final/v25/sdk-harness/sdk-export-only/actual-session.mjs';
const out='.artifacts/noncombat-low-pixel/r7-lifecycle.json',hash=p=>createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const binding=JSON.parse(fs.readFileSync('.artifacts/noncombat-low-pixel/r7-preview/adapter-receipt.json'));const report={buildId:binding.buildId,sourceCommit:binding.sourceCommit,candidateSha256:binding.candidateSha256,kind:'actual-r7-sdk-lifecycle-and-natural-defeat',saveSha256:hash(savePath),sdkSha256:hash(sdkPath),deviceVerified:false,gpuFpsMeasured:false,steps:0,checks:[],states:[],status:'running'};
const{Gr,vi,dn,wi,pa,Me,d}=await import(pathToFileURL(sdkPath));
let session,L,rootScript;const enc=s=>new TextEncoder().encode(s);
function expose(fn,key,name){const top=d.lua_gettop(L);d.lua_getglobal(L,enc(fn));let found=false;for(let i=1;i<50;i++){const k=d.lua_getupvalue(L,-1,i);if(!k)break;if(Buffer.from(k).toString()===key){d.lua_setglobal(L,enc(name));found=true;break}d.lua_pop(L,1)}d.lua_settop(L,top);assert(found,key)}
function value(i){const t=d.lua_type(L,i);if(t===0)return null;if(t===1)return d.lua_toboolean(L,i);if(t===3)return d.lua_tonumber(L,i);if(t===4)return Buffer.from(d.lua_tolstring(L,i)).toString();if(t!==5)return '<other>';const r={},abs=d.lua_absindex(L,i);d.lua_pushnil(L);while(d.lua_next(L,abs)!==0){r[value(-2)]=value(-1);d.lua_pop(L,1)}return r}
function status(){const top=d.lua_gettop(L);d.lua_getglobal(L,enc('__READ_STATUS'));assert.equal(d.lua_pcall(L,0,1,0),0);const r=value(-1);d.lua_settop(L,top);return r}
function step(){dn(session,1/60);report.steps++}
function check(name,ok){assert(ok,name);report.checks.push(name)}
function native(p){let n=session.runtime.roots[0];for(const name of p.split('/')){const a=n.children.filter(c=>c.name===name);assert.equal(a.length,1,p);n=a[0]}return n}
function tap(p){const n=native(p),boxes=wi(session),box=boxes.get(n.Id),matrix=pa(session,boxes).get(n.Id),q=Me(matrix,box.centerX,box.centerY);vi(session,'move',q.x,q.y);vi(session,'down',q.x,q.y);step();vi(session,'up',q.x,q.y);step()}
function record(name){const s=status();report.states.push({name,controls:session.runtime.controlsById.size,state:s});return s}
function until(fn,limit=1200){for(let i=0;i<limit;i++){const s=status();if(fn(s))return s;step()}throw Error('expected state timeout '+JSON.stringify(status()))}
function ready(){return until(s=>s.portraits.selection.phase==='ready'&&s.portraits.avatar.phase==='idle'&&s.portraits.avatar.owned===0)}
try{
 const save=JSON.parse(fs.readFileSync(savePath));session=Gr(save.assets.server,{templatesProject:save.assets.client,scripts:save.assets.scripts,serverConfig:save.serverLogic,canvasId:'pc-16-9',language:'LanguageChs'});
 rootScript=session.runtime.mountedScripts.find(s=>/abyss_ui(?:\.lua)?$/.test(s.path));L=rootScript.env;expose('OnUpdate','view','__VIEW');expose('OnDestroy','portraits','__PORTRAITS');
 session.runtime.runChunk(L,`function __READ_STATUS()
 local v=__VIEW;local b=v.run and v.run.combat
 return {mode=v.mode,characterOpen=v.characterOpen,phase=v.run and v.run.phase,hp=v.run and v.run.hp,maxHp=v.run and v.run.maxHp,busy=v.battleUI.busy,portraits=__PORTRAITS:status(),deathReveal=v.motion.deathReveal,entranceDone=v.motion.entranceDone,turn=b and b.turn}
 end`,'READ_ONLY_STATUS');
 check('fresh ready log',session.runtime.logs.some(l=>l.text==='ABYSS_UI ready'));
 const first=record('cold-menu-initialize');for(let i=0;i<120;i++)step();const idle=record('cold-menu-120');
 check('cold selection owned zero',idle.portraits.selection.owned===0);check('cold avatar owned zero',idle.portraits.avatar.owned===0);check('cold menu no controls created',report.states[0].controls===report.states[1].controls);
 tap('stage/menuPanel/start/hit');const partial=record('selection-partial');check('selection opened',partial.characterOpen);
 check('selection builds on demand',partial.portraits.selection.owned>0);check('57-shape main ready or building within initial two ticks',partial.portraits.selection.phase==='ready'||partial.portraits.selection.phase==='building'||partial.portraits.selection.phase==='revealing');
 tap('stage/characterPanel/cancel/hit');const cancelled=record('partial-cancel');check('partial cancel returns menu',!cancelled.characterOpen&&cancelled.mode==='menu');
 for(let i=0;i<120;i++)step();const cancelledIdle=record('cancelled-menu-120');check('cancelled hidden art does not build',cancelledIdle.portraits.selection.owned===cancelled.portraits.selection.owned);
 tap('stage/menuPanel/start/hit');ready();record('partial-reopen-complete');const counts=[];
 for(let i=0;i<20;i++){tap('stage/characterPanel/cancel/hit');tap('stage/menuPanel/start/hit');ready();counts.push(session.runtime.controlsById.size)}
 report.warmCounts=counts;check('twenty warm reopen controls stable',counts.every(n=>n===13556));
 tap('stage/characterPanel/confirm/hit');check('confirm reaches Neow',status().mode==='node');tap('stage/nodePanel/eventView/option1/hit');tap('stage/nodePanel/eventView/option2/hit');check('HP blessing +8',status().maxHp===88);tap('stage/nodePanel/eventView/option1/hit');check('Neow result continues map',status().mode==='map');
 function all(n){return[n,...n.children.flatMap(all)]}const next=session.runtime.roots.flatMap(all).find(n=>/^node\d+$/.test(n.name)&&n.visible&&n.children.some(c=>c.name==='hit'&&c.visible));assert(next);const hit=next.children.find(c=>c.name==='hit'),boxes=wi(session),box=boxes.get(hit.Id),q=Me(pa(session,boxes).get(hit.Id),box.centerX,box.centerY);vi(session,'move',q.x,q.y);vi(session,'down',q.x,q.y);step();vi(session,'up',q.x,q.y);step();check('map begins combat',status().phase==='combat');
 report.defeatTurns=[];
 for(let i=0;i<50&&status().phase==='combat';i++){
  until(s=>!s.busy||s.phase!=='combat');if(status().phase!=='combat')break;
  tap('stage/battlePanel/endTurn');for(let n=0;n<15;n++)step();until(s=>!s.busy||s.phase!=='combat');report.defeatTurns.push(record('natural-turn-'+i));
 }
 check('real natural defeat by normal turns',status().phase==='defeat');until(s=>!s.deathReveal&&s.entranceDone);const defeated=record('defeat-result-complete');check('defeat result mode',defeated.mode==='defeat');
 const menu=native('stage/menuPanel'),start=native('stage/menuPanel/start'),label=native('stage/menuPanel/start/officialResultLabel');
 check('result menu links hidden',!native('stage/menuPanel/v25MainMenu').visible);check('result title quit hidden',!native('stage/menuPanel/titleQuit').visible);check('result menu start face hidden',!native('stage/menuPanel/start/v25MenuFace').visible);
 check('original result label visible',label.visible&&label.text==='重新启程');check('original result start plate visible',native('stage/menuPanel/start/plate').visible);check('original result start border visible',native('stage/menuPanel/start/border').visible);check('settle border retained',native('stage/menuPanel/settle/border').visible);
 report.resultStyle={start:{x:start.anchoredPositionX,y:start.anchoredPositionY,w:start.sizeDeltaX,h:start.sizeDeltaY},label:{text:label.text,fontSize:label.fontSize,visible:label.visible},title:{fontSize:native('stage/menuPanel/title').fontSize}};
 const beforeRestart=status().portraits;tap('stage/menuPanel/start/hit');check('result restart reaches selection',status().characterOpen);ready();check('restart reuses selection art',status().portraits.selection.owned===beforeRestart.selection.owned&&status().portraits.selection.generation===beforeRestart.selection.generation);check('restart retains unbuilt hidden avatar',status().portraits.avatar.owned===beforeRestart.avatar.owned&&status().portraits.avatar.generation===beforeRestart.avatar.generation);record('result-restart-selection-ready');
 tap('stage/characterPanel/confirm/hit');check('restart reaches new Neow',status().mode==='node'&&status().phase!=='defeat');record('new-neow-after-real-defeat');
 for(const runtime of session.runtimes)for(const root of [...runtime.roots])runtime.destroyControl(root);check('all roots cleaned',session.runtimes.every(r=>r.controlsById.size===0));report.status='pass';
}catch(error){report.status='failed';report.error=String(error.stack);try{record('failure')}catch{}console.log(report.error);process.exitCode=1}
finally{report.logs=session?.runtime.logs??[];report.faults=report.logs.filter(l=>l.level==='lua-error'||/ABYSS_UI failed|prepare_failed|command_failed/.test(l.text));if(report.faults.length){report.status='failed';process.exitCode=1}report.sourceStable=hash(savePath)===report.saveSha256&&hash(sdkPath)===report.sdkSha256;for(const runtime of session?.runtimes??[])try{runtime.destroy()}catch{}fs.writeFileSync(out,JSON.stringify(report,null,2));console.log(out)}

