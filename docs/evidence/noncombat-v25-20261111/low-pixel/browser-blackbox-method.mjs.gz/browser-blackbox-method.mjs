import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
import {gzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
const service=JSON.parse(fs.readFileSync('.artifacts/noncombat-low-pixel/r7-final-service/service.json'));
const out=path.resolve('.artifacts/noncombat-low-pixel/r7-browser-'+Date.now());fs.mkdirSync(out,{recursive:true});
const {composeRectMatrix,identityMatrix,applyMatrix}=await import(pathToFileURL('F:/New folder/.artifacts/art-lab-simulator/studio/ui/layout.js'));
const {chromium}=createRequire('C:/Users/Administrator/AppData/Roaming/npm/node_modules/playwright/package.json')('playwright');
const temp=out+'/tmp';fs.mkdirSync(temp);
const browser=await chromium.launch({headless:true,executablePath:'C:/Users/Administrator/AppData/Local/ms-playwright/chromium-1248/chrome-win64/chrome.exe',env:{...process.env,TEMP:temp,TMP:temp},args:['--enable-gpu','--disable-extensions','--disable-features=MediaRouter']});
const hash=b=>createHash('sha256').update(b).digest('hex');
const report={kind:'independent-real-pointer-boundary-audit',buildId:service.buildId,saveSha256:service.saveSha256,rendererSha256:service.rendererSha256,cases:[],errors:[],out};
const all=n=>Array.isArray(n)?n.flatMap(all):[n,...(n.children??[]).flatMap(all)];
const find=(n,name)=>all(n).find(c=>c.name===name),child=(n,name)=>n.children.find(c=>c.name===name);
const plain=s=>String(s??'').replace(/<[^>]*>/g,'');
async function api(route,body){const r=await fetch(service.url+route,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body),signal:AbortSignal.timeout(60000)});const v=await r.json();assert(r.ok&&v.ok!==false,JSON.stringify(v));return v.value??v}
function matrices(s){const result=new Map();function visit(n,p){const t=composeRectMatrix(p,n.box,n);result.set(n.id,t);for(const c of n.children??[])visit(c,t)}for(const n of s.tree)visit(n,identityMatrix());return result}
for(const branch of ['hp','lament']){
 const sid='independent-noncombat-'+branch+'-'+Date.now(),entry={branch,sid,shots:[],checks:[],errors:[]};report.cases.push(entry);
 let context,page;
 try{
  await api('/editor/api/load-archive',{sessionId:sid,path:service.cases[0].archive});
  context=await browser.newContext({viewport:{width:1400,height:1000}});page=await context.newPage();
  page.on('pageerror',e=>entry.errors.push(String(e)));
  await page.goto(service.url+'/editor/play#'+sid);await page.addStyleTag({content:'#shell{width:1282px!important;height:722px!important;max-width:none!important;max-height:none!important;flex:none!important}'});
  await page.waitForFunction(()=>{const c=document.querySelector('canvas')?.getBoundingClientRect();return parseInt(document.querySelector('#frame')?.textContent.replace(/[^0-9]/g,''))>0&&c?.width===1280},{},{timeout:60000});
  const cv=page.locator('canvas').first(),rect=await cv.boundingBox();
  const state=()=>api('/editor/api/play',{sessionId:sid,action:'get',args:{inspect:true}});
  const point=(s,n)=>{assert(n,'control exists');const b=n.box,q=applyMatrix(matrices(s).get(n.id),b.left+b.width/2,b.bottom+b.height/2);return{x:rect.x+q.x/s.canvasWidth*rect.width,y:rect.y+(1-q.y/s.canvasHeight)*rect.height}};
  const tap=async(n,s)=>{s??=await state();const q=point(s,n);await page.mouse.click(q.x,q.y);await page.waitForTimeout(400)};
  const check=(name,predicate)=>{assert(predicate,name);entry.checks.push(name)};
  async function shot(name){const s=await state();assert(s.logs.some(l=>l.text==='ABYSS_UI ready'));const png=out+'/'+branch+'-'+name+'.png';await cv.screenshot({path:png});fs.writeFileSync(out+'/'+branch+'-'+name+'.state.json.gz',gzipSync(JSON.stringify(s)));entry.shots.push({name,path:png,sha256:hash(fs.readFileSync(png))});console.log(branch,name);return s}
  let s=await shot('01-menu');const menu=find(s.tree,'menuPanel'),start=child(menu,'start'),hit=child(start,'hit');
  if(branch==='hp'){
   const p=point(s,hit);await page.mouse.move(p.x,p.y);await page.waitForTimeout(200);s=await shot('02-menu-hover');
   check('menu hover face active',child(child(find(s.tree,'start'),'v25MenuFace'),'hover').visible);
   await page.mouse.down();await page.waitForTimeout(150);s=await shot('03-menu-down');check('menu pressed face active',child(child(find(s.tree,'start'),'v25MenuFace'),'pressed').visible);
   await page.mouse.move(rect.x+700,rect.y+100);await page.mouse.up();await page.waitForTimeout(300);s=await state();
   check('drag release outside does not start',!find(s.tree,'characterPanel').visible);
   await tap(child(find(menu,'titleQuit'),'hit'),s);s=await shot('04-exit-confirm');check('title quit opens exit panel',find(s.tree,'exitPanel').visible);
   await tap(hit,s);s=await state();check('exit blocks underlying start',find(s.tree,'exitPanel').visible&&!find(s.tree,'characterPanel').visible);
   await tap(child(child(find(s.tree,'exitPanel'),'cancel'),'hit'),s);s=await state();check('exit cancel restores menu',!find(s.tree,'exitPanel').visible&&find(s.tree,'menuPanel').visible);
  }
  s=await state();await tap(child(child(find(s.tree,'menuPanel'),'start'),'hit'),s);
  s=await state();for(let i=0;i<80&&find(find(s.tree,'characterPanel'),'hint')?.text?.includes('正在载入');i++){await page.waitForTimeout(300);s=await state()}
  s=await shot('05-selection-ready');check('selection opens',find(s.tree,'characterPanel').visible);
  let panel=find(s.tree,'characterPanel');
  if(branch==='hp'){
   await tap(child(find(panel,'deckOpen'),'hit'),s);s=await shot('06-starter-deck');check('starter deck modal opens',child(find(s.tree,'characterPanel'),'deckView').visible);
   const deck=child(find(s.tree,'characterPanel'),'deckView');const cards=deck.children.filter(n=>/^deckCard\d+$/.test(n.name)&&n.visible);check('starter deck displays ten cards',cards.length===10);
   await tap(child(child(find(s.tree,'characterPanel'),'confirm'),'hit'),s);s=await state();check('starter deck blocks confirm',child(find(s.tree,'characterPanel'),'deckView').visible&&find(s.tree,'characterPanel').visible&&!find(s.tree,'nodePanel').visible);
   await tap(child(child(child(find(s.tree,'characterPanel'),'deckView'),'close'),'hit'),s);s=await state();check('deck close restores selection',!child(find(s.tree,'characterPanel'),'deckView').visible&&find(s.tree,'characterPanel').visible);
   await tap(child(child(find(s.tree,'characterPanel'),'cancel'),'hit'),s);s=await state();check('selection cancel restores menu',!find(s.tree,'characterPanel').visible&&find(s.tree,'menuPanel').visible);
   const p=point(s,child(child(find(s.tree,'menuPanel'),'start'),'hit'));await page.mouse.dblclick(p.x,p.y,{delay:20});await page.waitForTimeout(600);s=await state();check('double start leaves single selection',find(s.tree,'characterPanel').visible&&!find(s.tree,'nodePanel').visible);
  }
  s=await state();panel=find(s.tree,'characterPanel');const confirm=child(child(panel,'confirm'),'hit');
  await tap(confirm,s);s=await shot('07-neow-intro');check('selection confirm reaches blessing',!find(s.tree,'characterPanel').visible&&find(s.tree,'nodePanel').visible);
  let event=find(s.tree,'eventView');check('intro one option',event.children.filter(n=>/^option\d+$/.test(n.name)&&n.visible).length===1);
  await tap(child(child(event,'option1'),'hit'),s);s=await shot('08-neow-offers');event=find(s.tree,'eventView');
  check('natural first-run two blessing choices',event.children.filter(n=>/^option\d+$/.test(n.name)&&n.visible).length===2);
  await tap(child(child(event,branch==='hp'?'option2':'option1'),'hit'),s);s=await shot('09-neow-result');event=find(s.tree,'eventView');
  check('one result continuation',event.children.filter(n=>/^option\d+$/.test(n.name)&&n.visible).length===1);
  entry.resultText=plain(find(event,'body').text);entry.resultLabels=all(s.tree).filter(n=>n.kind==='textbox'&&n.text).map(n=>[n.name,plain(n.text)]).filter(([n])=>['player','piles','title','floor','hp'].includes(n));
  await tap(child(child(event,'option1'),'hit'),s);s=await shot('10-map');check('blessing continue reaches map',find(s.tree,'mapPanel').visible&&!find(s.tree,'nodePanel').visible);
  const next=all(s.tree).find(n=>/^node\d+$/.test(n.name)&&n.visible&&n.children.some(c=>c.name==='hit'&&c.visible));assert(next);await tap(child(next,'hit'),s);await page.waitForTimeout(1400);s=await shot('11-first-battle');const battle=find(s.tree,'battlePanel');check('reachable map node starts combat',battle.visible);
  entry.battleTexts=all(battle).filter(n=>n.kind==='textbox'&&n.text).map(n=>({name:n.name,text:plain(n.text)}));
  const cards=battle.children.filter(n=>/^card\d+$/.test(n.name)&&n.visible),defend=cards.find(c=>plain(find(c,'name')?.text).includes('防御'));
  check('natural hand has Defend for safe no-target input',!!defend);
  await tap(child(defend,'hit'),s);s=await state();await tap(find(find(s.tree,'battlePanel'),'playArea'),s);await page.waitForTimeout(600);for(let wait=0;wait<40;wait++){s=await state();if(find(s.tree,'battlePanel').children.filter(n=>/^card\d+$/.test(n.name)&&n.visible).length===cards.length-1)break;await page.waitForTimeout(150)}s=await shot('12-defend-played');
  entry.afterPlayTexts=all(find(s.tree,'battlePanel')).filter(n=>n.kind==='textbox'&&n.text).map(n=>({name:n.name,text:plain(n.text)}));
  const after=find(s.tree,'battlePanel').children.filter(n=>/^card\d+$/.test(n.name)&&n.visible);check('actual Defend play removes one hand card',after.length===cards.length-1);
  entry.status='pass';
 }catch(error){entry.status='failed';entry.error=String(error.stack);entry.cause=error.cause?String(error.cause.stack??error.cause):null;try{await page?.screenshot({path:out+'/'+branch+'-failure.png'})}catch{}console.log(entry.error)}
 finally{await context?.close();try{await api('/editor/api/play',{sessionId:sid,action:'stop',args:{}})}catch(error){entry.stopError=String(error)}}
}
await browser.close();report.status=report.cases.every(c=>c.status==='pass'&&!c.errors.length)?'pass':'failed';fs.writeFileSync(out+'/report.json',JSON.stringify(report,null,2));console.log(out);process.exitCode=report.status==='pass'?0:1;
