import {readFileSync} from 'node:fs';
import assert from 'node:assert/strict';
const path='tests/helpers/combined-epoch/source-epoch-runtime.mjs';
const src=readFileSync(path,'utf8');
const {createSourceEpochProjector:fast}=await import('data:text/javascript;base64,'+Buffer.from(src).toString('base64'));
const {createSourceEpochProjector:old}=await import('data:text/javascript;base64,'+Buffer.from(src.replace('const proof=cloneProof(input);','const proof=JSON.parse(JSON.stringify(input));')).toString('base64'));
const basic=()=>({schemaVersion:1,normalization:'LF',currentCommit:'a'.repeat(40),owners:[],current:{},targets:{}});
const cases={
 alias:()=>{const x={a:[1,'x']};return {a:x,b:x}},
 date:()=>new Date('2020-01-01'),
 toJSON:()=>({toJSON(){return {a:1}}}),
 getter:()=>({get a(){return 1}}),
 proxy:()=>new Proxy({a:1},{}),
 undefined:()=>({a:undefined,b:[undefined]}),
 specialNumbers:()=>[NaN,Infinity,-Infinity,-0],
 sparse:()=>new Array(4),
 nullProto:()=>Object.assign(Object.create(null),{a:1}),
 protoKey:()=>JSON.parse('{"__proto__":{"x":1}}'),
 customProto:()=>Object.assign(Object.create({x:1}),{a:2}),
 cycle:()=>{const a={};a.a=a;return a},
 bigInt:()=>1n,
 function:()=>({a:()=>1}),
 nonEnumGetter:()=>Object.defineProperty({a:1},'hidden',{get(){throw Error('hidden')}}),
 arrayMapOverride:()=>Object.defineProperty([1,2],'map',{value(){return ['BAD']}}),
 arraySpecies:()=>Object.defineProperty([1,2],'constructor',{value:{[Symbol.species]:class Weird extends Array{}}}),
};
let fail=0;
for(const [name,make] of Object.entries(cases)){
 const run=fn=>{try{return {proof:fn({...basic(),extra:make()}).proof}}catch(e){return {error:e.constructor.name,message:e.message}}};
 const a=run(fast),b=run(old);
 try{assert.deepStrictEqual(a,b);if(a.proof&&name==='alias')assert.notEqual(a.proof.extra.a,a.proof.extra.b);console.log('PASS',name)}catch(e){console.log('FAIL',name,JSON.stringify(a),JSON.stringify(b));fail++}
}
console.log('mismatches',fail);
const input={...basic(),extra:Array.from({length:10},(_,i)=>i)};
let actual,expected,error;
Object.defineProperty(Array.prototype,'9',{configurable:true,set(){throw Error('inherited index setter executed')}});
try{expected=old(input).proof;actual=fast(input).proof}catch(e){error=e}finally{delete Array.prototype[9]}
assert.equal(error,undefined);assert.deepStrictEqual(actual,expected);console.log('PASS inherited array index setter');
