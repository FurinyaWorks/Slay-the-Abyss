import os, subprocess, hashlib, json, pathlib, time
root=pathlib.Path('/workspace/scratch/c1a4970a76e0/m7-deck-sort-repair');out=root.parent/'m7-deck-sort-evidence';os.chdir(root)
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def snapshot():
 names=subprocess.check_output(['git','ls-files','-z']).decode().split('\0')
 names += [str(p.relative_to(root)) for p in (root/'build').rglob('*') if p.is_file()]
 names += [str(p) for p in (root/'node_modules').resolve().rglob('*') if p.is_file()]
 names += [str(pathlib.Path(subprocess.check_output(['which','node']).decode().strip()).resolve()),str(out/'validate-official.py')]
 return {p:sha(p) if pathlib.Path(p).is_file() else None for p in sorted(set(names)) if p}
before=snapshot();(out/'official-inputs-before.json').write_text(json.dumps(before,ensure_ascii=False,indent=2)+'\n')
cmd=['node','--test','--test-concurrency=1','tests/official-assets-runtime.test.mjs'];start=time.time()
with (out/'official-complete.log').open('wb') as f: r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
after=snapshot();(out/'official-inputs-after.json').write_text(json.dumps(after,ensure_ascii=False,indent=2)+'\n')
row=dict(command=cmd,exitCode=r.returncode,startedUnix=start,elapsedSeconds=time.time()-start,logSha256=sha(out/'official-complete.log'),snapshotItems=len(before),materializedItems=sum(v is not None for v in before.values()),inputChanges=[p for p in sorted(set(before)|set(after)) if before.get(p)!=after.get(p)])
(out/'official-validation.json').write_text(json.dumps(row,ensure_ascii=False,indent=2)+'\n');print(json.dumps(row),flush=True)
