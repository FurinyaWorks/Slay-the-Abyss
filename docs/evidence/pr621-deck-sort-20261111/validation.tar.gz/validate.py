import os, subprocess, hashlib, json, pathlib, time
root=pathlib.Path('/workspace/scratch/c1a4970a76e0/m7-deck-sort-repair')
out=pathlib.Path('/workspace/scratch/c1a4970a76e0/m7-deck-sort-evidence')
os.chdir(root)
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def snapshot():
    names=subprocess.check_output(['git','ls-files','-z']).decode().split('\0')
    names += [str(p.relative_to(root)) for p in (root/'build').rglob('*') if p.is_file()]
    names += [str(p) for p in (root/'node_modules').resolve().rglob('*') if p.is_file()]
    names += [str(pathlib.Path(subprocess.check_output(['which','node']).decode().strip()).resolve()),str(out/'validate.py')]
    return {p:sha(p) if pathlib.Path(p).is_file() else None for p in sorted(set(names)) if p}
commands=[('behavior',['node','--test','--test-concurrency=1','tests/deck-browse-filters.test.mjs','tests/deck-item-lifecycle.test.mjs','tests/deck-scroll-detail.test.mjs','tests/official-assets-runtime.test.mjs']),('pile-view',['node','scripts/test-lua.mjs','tests/lua/deck_pile_view.lua']),('pile-entry',['node','scripts/test-lua.mjs','tests/lua/game_ui_pile_entry.lua']),('source-epoch-blocker',['node','--test','--test-concurrency=1','tests/official-battle-pile-source-epoch.test.mjs']),('syntax',['npm','run','check:syntax']),('guidance',['npm','run','check:guidance']),('backlog',['npm','run','verify:backlog']),('network',['npm','run','check:network']),('diff',['git','diff','--check'])]
results=[]
initial=snapshot();(out/'inputs-before.json').write_text(json.dumps(initial,ensure_ascii=False,indent=2)+'\n')
for name,cmd in commands:
    before=snapshot();start=time.time()
    with (out/(name+'.log')).open('wb') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
    after=snapshot();changes=[p for p in sorted(set(before)|set(after)) if before.get(p)!=after.get(p)]
    row=dict(name=name,command=cmd,exitCode=r.returncode,startedUnix=start,elapsedSeconds=time.time()-start,logSha256=sha(out/(name+'.log')),inputChanges=changes)
    results.append(row);(out/'validation.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(row),flush=True)
final=snapshot();(out/'inputs-after.json').write_text(json.dumps(final,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'snapshotItems':len(initial),'materializedItems':sum(v is not None for v in initial.values()),'inputChanges':[p for p in sorted(set(initial)|set(final)) if initial.get(p)!=final.get(p)]}),flush=True)
