from pathlib import Path
import subprocess
source=Path('src/lua/abyss_skill_feedback.lua').read_text()
probe=Path('/tmp/skill-feedback-review/probe.lua').read_text()
mutations={
 'lose_false_nil_override': ('if handled then return family end','if family then return family end'),
 'swap_effect_priority': ("return block and 'defend' or buff and 'buff'", "return buff and 'buff' or block and 'defend'"),
 'eager_intent_lookup': ('local byEnemy=moves[c.enemyId]', 'local ignored=c.intentId; local byEnemy=moves[c.enemyId]'),
 'lazy_weight_read': ("if c.weight=='heavy' and family=='melee'", "if family=='melee' and c.weight=='heavy'"),
 'drop_damage_family': ("family~='projectile' and family~='poison' and family~='heavy'", "family~='projectile' and family~='heavy'"),
}
for name,(old,new) in mutations.items():
 assert source.count(old)==1,(name,source.count(old))
 target=Path('/tmp/skill-feedback-review/'+name+'.lua');target.write_text(source.replace(old,new))
 script=Path('/tmp/skill-feedback-review/test-'+name+'.lua');script.write_text(probe.replace("dofile('src/lua/abyss_skill_feedback.lua')",f"dofile('{target}')"))
 r=subprocess.run(['node','node_modules/fengari-node-cli/src/lua-cli.js','-e',f"dofile('{script}')"],capture_output=True,text=True)
 assert r.returncode!=0 and 'mismatch' in r.stderr,(name,r.returncode,r.stdout,r.stderr)
 Path('/tmp/skill-feedback-review/'+name+'.stderr.log').write_text(r.stderr)
 print('KILLED',name)
