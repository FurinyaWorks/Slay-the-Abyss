local before = dofile('/tmp/skill-feedback-review/base.lua')
local after = dofile('src/lua/abyss_skill_feedback.lua')
local checks=0
local function run(mod,kind,values,changing)
  local reads, counts={},{}
  local function proxy(name,values)
    return setmetatable({}, {
      __index=function(_,key)
        local path=name..'.'..tostring(key)
        reads[#reads+1]=path;counts[path]=(counts[path] or 0)+1
        if changing and counts[path]>1 then return nil end
        return values[key]
      end,
      __newindex=function() error('WRITE') end
    })
  end
  local effects={}
  for i,op in ipairs(values.ops or {}) do effects[i]=proxy('effect'..i,{op=op}) end
  local c=proxy('context',{enemyId=values.enemy,intentId=values.intent,family=values.family,intentKind=values.intentKind,weight=values.weight,statusKind=values.statusKind,effects=effects})
  local d=proxy('detail',{effectType=values.override,status=values.status})
  local old=math.random;math.random=function() error('RNG') end
  local ok,result=pcall(mod.resolve,kind,d,c); math.random=old
  return ok, tostring(result),table.concat(reads,',')
end
local function compare(kind,values,changing)
 local a,b,c=run(before,kind,values,changing); local x,y,z=run(after,kind,values,changing)
 assert(a==x and b==y and c==z,kind..' mismatch: '..b..'/'..y..' reads '..c..'/'..z)
 checks=checks+1
end
for _,kind in ipairs({'intent','damage','status','status_damage','hp_loss','block','heal','play','other'}) do
 for _,family in ipairs({false,'none','melee','heavy','projectile','poison','bind','defend','buff','dot','unknown',0}) do
  for _,override in ipairs({false,'melee','heavy','projectile','poison','bind','buff','defend','dot','bad'}) do
   for _,intentKind in ipairs({'attack','defend','buff','charge','debuff','sleep'}) do
    for _,enemy in ipairs({'chosen','unknown'}) do
     for _,changing in ipairs({false,true}) do
      compare(kind,{family=family,override=override,intentKind=intentKind,enemy=enemy,intent='zap',weight='heavy',status='weak',statusKind='buff',ops={'applyStatus','gainStatus','block'}},changing)
     end
    end
   end
  end
 end
end
for _,ops in ipairs({{}, {'block','damage','applyStatus'}, {'applyStatusAll','gainStatus'}, {'enemyHealAll','block'}, {'enemyStrengthAll'}, {'damageAll'}, {'damageEqualToBlock'}, {'enemyVampireDamage'}, {'unknown'}}) do
 compare('intent',{ops=ops},false); compare('damage',{ops=ops,weight='heavy'},true)
end
print('INDEPENDENT_PROXY_DIFFERENTIAL_PASS '..checks)
