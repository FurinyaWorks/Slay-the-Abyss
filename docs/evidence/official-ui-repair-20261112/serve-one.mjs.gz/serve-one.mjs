import fs from'node:fs';import path from'node:path';import{pathToFileURL}from'node:url';import assert from'node:assert/strict';
const args=process.argv.slice(2),at=args.indexOf('--output');assert(at>=0);const out=path.resolve(args[at+1]);fs.mkdirSync(out,{recursive:true});
let source=fs.readFileSync('experiments/battle-stage-review/serve.mjs','utf8');
const anchor=/const cases=\[[\s\S]+?\];\r?\nfor\(const c of cases\)/;assert(anchor.test(source));
source=source.replace(anchor,"const cases=[{name:'ten',file:'hud.save.json',title:'双敌十牌 · UI修复候选',description:'拖攻击牌检查方向、换敌、自由瞄准与取消。'}];\nfor(const c of cases)");
source=source.replace("from './renderer-ticker-patch.mjs'","from "+JSON.stringify(pathToFileURL(path.resolve('experiments/battle-stage-review/renderer-ticker-patch.mjs')).href));
source=source.replaceAll('战斗页面 · 阶段评审','官方UI修复 · 待实机验收').replace('本轮牌堆与遗物详情候选；可实际游玩。','本轮手机锁敌与能量球修复；未通过官方手机视觉验收。');
const file=path.join(out,'entry.mjs');fs.writeFileSync(file,source);await import(pathToFileURL(file));
