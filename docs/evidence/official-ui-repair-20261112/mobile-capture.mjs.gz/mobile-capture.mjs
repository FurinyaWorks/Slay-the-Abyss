import fs from'node:fs';import path from'node:path';import assert from'node:assert/strict';import{createRequire}from'node:module';import{gzipSync}from'node:zlib';import{createHash}from'node:crypto';
const[serviceFile,output,archive='review-ten.save.json',device='mobile-16-9']=process.argv.slice(2);
const service=JSON.parse(fs.readFileSync(serviceFile)),base=service.url,out=path.resolve(output);fs.mkdirSync(out,{recursive:true});
const sid='official-ui-touch-'+Date.now(),report={kind:'headless-Simulator-trusted-touch',service,archive,device,officialClient:false,physicalPhone:false,shots:[],errors:[]};
const api=async(route,body)=>{const r=await fetch(base+route,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body),signal:AbortSignal.timeout(90000)});const s=await r.json();assert(r.ok&&s.ok!==false,JSON.stringify(s));return s.value??s};
const state=()=>api('/editor/api/play',{sessionId:sid,action:'get',args:{inspect:true}});
await api('/editor/api/load-archive',{sessionId:sid,path:archive});
const{chromium}=createRequire('C:/Users/Administrator/AppData/Roaming/npm/node_modules/playwright/package.json')('playwright');
const browser=await chromium.launch({headless:true,executablePath:'C:/Users/Administrator/AppData/Local/ms-playwright/chromium-1248/chrome-win64/chrome.exe',args:['--enable-gpu','--disable-extensions','--disable-features=MediaRouter']});
const context=await browser.newContext({viewport:{width:1700,height:1050},hasTouch:true}),page=await context.newPage();
page.on('pageerror',e=>report.errors.push(String(e)));
const walk=(nodes,fn)=>{for(const n of nodes??[]){fn(n);walk(n.children,fn)}},find=(nodes,name)=>{let result;walk(nodes,n=>{if(n.name===name&&!result)result=n});return result};
const hash=p=>createHash('sha256').update(fs.readFileSync(p)).digest('hex');
let cdp;
try{
 const begun=performance.now();await page.goto(base+'/editor/play#'+sid);
 await page.evaluate(async()=>{const{PixiPlayRenderer}=await import('/editor/play-renderer.js');const prior=PixiPlayRenderer.prototype.applyScene;PixiPlayRenderer.prototype.applyScene=async function(...a){window.__UI_RENDERER=this;return prior.apply(this,a)}});
 await page.waitForFunction(()=>document.querySelector('#deviceSel')?.options.length>0,{},{timeout:90000});
 await page.selectOption('#deviceSel',device);
 const width=device==='mobile-19.5-9'?1560:1280;
 await page.addStyleTag({content:`#shell{width:${width+2}px!important;height:722px!important;max-width:none!important;max-height:none!important;flex:none!important}`});
 let s;for(let i=0;i<160;i++){s=await state();if(s.platform==='TOUCHSCREEN'&&find(s.tree,'officialFigure')?.visible&&s.frame>2)break;await page.waitForTimeout(250)}
 assert(s.platform==='TOUCHSCREEN'&&s.running&&find(s.tree,'officialFigure')?.visible,'actual touch platform must be ready');
 report.firstObservedReadyMs=performance.now()-begun;report.canvas={width:s.canvasWidth,height:s.canvasHeight,platform:s.platform,device:s.device};
 await page.waitForFunction(()=>window.__UI_RENDERER?.nodes?.size>0,{},{timeout:30000});
 const canvas=page.locator('canvas').first(),rect=await canvas.boundingBox();report.canvasRect=rect;
 const position=async (n,parent)=>page.evaluate(({id,parent,x,y})=>{const node=__UI_RENDERER.nodes.get(id);if(node){const p=node.getGlobalPosition();return{x:p.x,y:p.y}}
 const box=__UI_RENDERER.nodes.get(parent);if(!box)throw Error('Missing displayed node '+id+' and parent '+parent);
 const p=box.toGlobal({x,y:-y});return{x:p.x,y:p.y};},{id:n.id,parent:parent?.id,x:n.anchoredPositionX??0,y:n.anchoredPositionY??0});
 const xy=p=>({x:rect.x+p.x/s.canvasWidth*rect.width,y:rect.y+p.y/s.canvasHeight*rect.height});
 const shot=async(name)=>{await page.waitForTimeout(180);const q=await state();fs.writeFileSync(out+'/'+name+'.state.json.gz',gzipSync(JSON.stringify(q)));await canvas.screenshot({path:out+'/'+name+'.png'});report.shots.push({name,sha256:hash(out+'/'+name+'.png'),frame:q.frame});return q};
 await shot('ready');
 const battle=find(s.tree,'battlePanel');
 let card;for(let i=1;i<=10;i++){const c=find(battle.children,'card'+i);let strike=false;walk(c.children,n=>{if(n.text==='普通攻击')strike=true});if(strike){card=c;break}}
 assert(card,'real attack card must be present');
 const hit=find(card.children,'hit'),actors=find(s.tree,'actorLayer').children.filter(n=>n.name!=='hero'&&n.visible&&find(n.children,'hit'));
 assert.equal(actors.length,2,'multi-enemy fixture must actually show two enemies');
 const pickup=xy(await position(hit,card)),target1=xy(await position(find(actors[0].children,'hit'),actors[0])),target2=xy(await position(find(actors[1].children,'hit'),actors[1]));
 cdp=await context.newCDPSession(page);let touchDown=false;
 const touch=async(type,p)=>{await cdp.send('Input.dispatchTouchEvent',{type,touchPoints:type==='touchEnd'?[]:[{x:p.x,y:p.y,id:17,radiusX:2,radiusY:2,force:1}]});touchDown=type!=='touchEnd';await page.waitForTimeout(180)};
 report.points={pickup,target1,target2};
 await touch('touchStart',pickup);await touch('touchMove',target1);await shot('lock-first');
 await touch('touchMove',target2);await shot('lock-second');
 const free=xy({x:s.canvasWidth*.55,y:s.canvasHeight*.35});await touch('touchMove',free);await shot('free');
 await touch('touchMove',pickup);await touch('touchEnd');const cancelled=await shot('cancel');
 const layer=find(find(cancelled.tree,'battlePanel').children,'dragLayer');assert.equal(layer.visible,false,'return to hand and release must cancel');
 if(process.argv.includes('--play')){
  await page.waitForTimeout(700);
  await touch('touchStart',pickup);await touch('touchMove',target2);await shot('before-release');await touch('touchEnd');await page.waitForTimeout(1800);
  const played=await shot('after-play');const panel=find(played.tree,'battlePanel');
  report.play={energy:find(panel.children,'energy').text,lastSlotVisible:find(panel.children,'card10').visible};
  assert.equal(report.play.energy,'2/3','one actual touch attack spends exactly one energy');
  assert.equal(report.play.lastSlotVisible,false,'one card leaves the ten-card hand');
 }
 report.logs=cancelled.logs;report.status='captured-awaiting-human-and-physical-phone-review';
}catch(e){report.status='failed';report.error=String(e.stack);try{await page.screenshot({path:out+'/failure.png'})}catch{}process.exitCode=1}
finally{try{await cdp?.detach()}catch{}await context.close();await browser.close();try{report.stop=await api('/editor/api/play',{sessionId:sid,action:'stop',args:{}})}catch(e){report.stopError=String(e)}fs.writeFileSync(out+'/receipt.json',JSON.stringify(report,null,2));console.log(JSON.stringify({out,status:report.status,error:report.error,shots:report.shots.length,canvas:report.canvas,points:report.points}));}
