import fs from'node:fs';import path from'node:path';import assert from'node:assert/strict';import{pathToFileURL}from'node:url';import{createHash}from'node:crypto';
import{loadNativeUiEncoder}from'../../scripts/native-ui-encoder.mjs';import{writeScriptBatch}from'../../scripts/native-script-batch.mjs';import{embeddedScripts}from'../../scripts/native-script-inventory.mjs';
const dir=path.resolve('.artifacts/official-ui-bugs/v2/direct-battle');fs.mkdirSync(dir,{recursive:true});
const parent=JSON.parse(fs.readFileSync('build/official-ui-repair-v2/d3b4c46e-acf0-454d-8193-4618d548fbae/candidate.json'));
const hash=b=>createHash('sha256').update(b).digest('hex');assert.equal(hash(fs.readFileSync(parent.candidate.path)),parent.candidate.sha256);
const fixture=JSON.parse(fs.readFileSync('.artifacts/official-ui-bugs/v2/preview/hud.save.json'));
const source=fixture.assets.scripts.find(s=>s.path==='abyss_game_ui.lua').source;
const tool='D:/MiliastraTools/genshin-miliastra-mcp',wire=await import(pathToFileURL(tool+'/src/scene/wire.mjs'));
const{luaSyntaxError}=await import(pathToFileURL(tool+'/src/client-check.mjs'));const{native}=await loadNativeUiEncoder(tool);
const mapPath=writeScriptBatch(parent.candidate.path,[{name:'abyss_game_ui',source}],dir,{...wire,clientScriptRecord:native.clientScriptRecord,luaSyntaxError});
const read=embeddedScripts({mapPath,includeSource:true},wire).scripts;
assert.equal(read.length,360);for(const m of read)assert.equal(hash(m.source),m.name==='abyss_game_ui'?hash(source):parent.moduleDigests[m.name],m.name);
// The batch writer must preserve every non-script section byte-for-byte.
const a=wire.fields(wire.container(fs.readFileSync(parent.candidate.path))),b=wire.fields(wire.container(fs.readFileSync(mapPath)));
assert.deepEqual(a.filter(f=>f.id!==50).map(f=>hash(f.raw)),b.filter(f=>f.id!==50).map(f=>hash(f.raw)));
const receipt={kind:'derived-direct-battle-diagnostic-gil',parentBuildId:parent.buildId,parentCandidateSha256:parent.candidate.sha256,
 sourceCommit:parent.sourceCommit,parentSourceDirty:parent.sourceDirty,mapPath,candidateSha256:hash(fs.readFileSync(mapPath)),
 changedModule:'abyss_game_ui',originalModuleSha256:parent.moduleDigests.abyss_game_ui,fixtureModuleSha256:hash(source),modules:read.length,
 nonScriptSectionsIdentical:true,gameplayRulesChanged:false,fixture:'Existing #621 ten real cards, two live slimes, three potions; startup bypass only. Not a natural campaign state.',
 officialImport:'not_run',officialReady:'not_run',physicalPhone:'not_run',publish:false};
fs.writeFileSync(dir+'/receipt.json',JSON.stringify(receipt,null,2));console.log(JSON.stringify(receipt));
