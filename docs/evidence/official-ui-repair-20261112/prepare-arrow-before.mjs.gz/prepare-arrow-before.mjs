import fs from 'node:fs';import {execFileSync}from'node:child_process';import{createHash}from'node:crypto';
const dir='.artifacts/official-ui-bugs/before-service/workspace',hash=b=>createHash('sha256').update(b).digest('hex');
const input=fs.readFileSync(dir+'/review-ten.save.json'),save=JSON.parse(input),mutations=[];
for(const name of ['abyss_battle_card_view','abyss_battle_aim_arrow']){
 const m=save.assets.scripts.find(s=>s.path===name+'.lua'),before=hash(m.source);
 m.source=execFileSync('git',['show','680be9c5:src/lua/'+name+'.lua'],{encoding:'utf8',windowsHide:true});
 mutations.push({module:m.path,beforeSha256:before,afterSha256:hash(m.source),gitSource:'680be9c5:src/lua/'+name+'.lua'});
}
fs.writeFileSync(dir+'/review-aim-before.save.json',JSON.stringify(save));
fs.writeFileSync('.artifacts/official-ui-bugs/arrow-before-mutation.json',JSON.stringify({kind:'diagnostic-before-counterfactual',inputSha256:hash(input),outputSha256:hash(JSON.stringify(save)),mutations,officialEvidence:false,gameplayRulesChanged:false},null,2));
