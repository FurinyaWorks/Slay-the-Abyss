import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {componentAliasCiSourceProof as proof,createComponentAliasCiProjector,preComponentAliasCiSource as project} from '../../tests/helpers/component-alias-ci-source-inverse.mjs';
import {ciSourceAtEpoch,preComponentUiCiSource,preComponentUiCiFoundationSource} from '../../tests/helpers/component-ui-ci-source-inverse.mjs';
import {preFoundationFixCiSource} from '../../tests/helpers/foundation-fix-ci-source-inverse.mjs';
const base='06bc84ee4b2b3c7b51486df678ac4551ced1b084';
let assertions=0;
const eq=(a,b,message)=>{assert.deepEqual(a,b,message);assertions++;};
const rejects=(f)=>{assert.throws(f);assertions++;};
for(const [path,b] of Object.entries(proof.files)){
 const original=execFileSync('git',['show',`${base}:${path}`],{encoding:'utf8'}).replaceAll('\r\n','\n');
 const current=readFileSync(path,'utf8').replaceAll('\r\n','\n');
 eq(b.beforeSource,original,'before snapshot exactly Git');eq(b.afterSource,current,'after snapshot exactly current');
 eq(project(path,current),original);eq(project(path,current.replaceAll('\n','\r\n')),original);
 eq(ciSourceAtEpoch(path,current,'foundationFix'),original);
 eq(ciSourceAtEpoch(path,current,'componentAliasFix'),current);
 eq(preComponentUiCiSource(path,current),preComponentUiCiFoundationSource(path,preFoundationFixCiSource(path,original)),'historical chain order');
 for(const altered of [current+' ',current.slice(1),current.replace('import','//import'),null,undefined,{},false,1])eq(project(path,altered),altered);
 for(const foreign of ['__proto__','constructor','toString','../'+path,path+'/','/'+path,path.toUpperCase()])eq(project(foreign,current),current);
 for(const key of ['beforeSource','afterSource','beforeSha256','afterSha256','beforeGitBlob','afterGitBlob']){
  const damaged=structuredClone(proof);delete damaged.files[path][key];rejects(()=>createComponentAliasCiProjector(damaged));
 }
 const missing=structuredClone(proof);delete missing.files[path];rejects(()=>createComponentAliasCiProjector(missing));
 console.log(`PASS exact Git/current identity, CRLF, complete-source/path boundary, missing fields, epoch chain: ${path}`);
}
for(const field of ['schemaVersion','normalization','beforeCommit']){const damaged=structuredClone(proof);damaged[field]='wrong';rejects(()=>createComponentAliasCiProjector(damaged));}
const extra=structuredClone(proof);extra.files['other']=Object.values(extra.files)[0];rejects(()=>createComponentAliasCiProjector(extra));
const owned=createComponentAliasCiProjector(proof);for(const b of Object.values(owned.proof.files))eq(Object.isFrozen(b),true);
const archives=execFileSync('git',['ls-tree','-r','--name-only',base,'tests/helpers'],{encoding:'utf8'}).trim().split('\n').filter(p=>p.endsWith('.gz'));
for(const path of archives)eq(execFileSync('git',['hash-object',path],{encoding:'utf8'}).trim(),execFileSync('git',['rev-parse',`${base}:${path}`],{encoding:'utf8'}).trim(),`historical archive unchanged: ${path}`);
console.log(`PASS ${archives.length} historical helper archives byte-identical to Git base`);
console.log(JSON.stringify({assertions,failures:0,node:process.version,platform:process.platform}));
