import assert from 'node:assert/strict';
import {mkdtempSync,cpSync,copyFileSync,mkdirSync,writeFileSync,readFileSync,readdirSync,linkSync,symlinkSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join,resolve} from 'node:path';
import {spawnSync} from 'node:child_process';
const repo=process.cwd();
let passed=0;
function fixture(run){const root=mkdtempSync(join(tmpdir(),'independent-component-alias-'));try{
 for(const dir of ['scripts','data'])cpSync(resolve(dir),join(root,dir),{recursive:true});
 for(const file of ['package.json','package-lock.json','.release-please-manifest.json','CHANGELOG.md'])copyFileSync(resolve(file),join(root,file));
 mkdirSync(join(root,'tools'));copyFileSync(resolve('tools/render_traveler_cards.py'),join(root,'tools/render_traveler_cards.py'));
 mkdirSync(join(root,'art'));writeFileSync(join(root,'art/disabled-original.bin'),'original disabled artwork');mkdirSync(join(root,'out'));
 run(root);
}finally{rmSync(root,{recursive:true,force:true});}}
for(const mode of ['hardlink','symlink'])for(const source of ['scripts/ui-profile.mjs','scripts/art/lightweight-2d-assets.mjs','art/disabled-original.bin'])fixture(root=>{
 const input=join(root,source),target=join(root,'out/abyss_component_binding.lua');const before=readFileSync(input);
 (mode==='hardlink'?linkSync:symlinkSync)(input,target);
 writeFileSync(join(root,'out/abyss_theme.lua'),'existing theme sentinel');
 const result=spawnSync(process.execPath,['scripts/build-ui.mjs','out'],{cwd:root,encoding:'utf8'});
 assert.notEqual(result.status,0);assert.match(result.stderr,/Output must not overwrite an input file/);
 assert.deepEqual(readFileSync(input),before);assert.deepEqual(readdirSync(join(root,'out')).sort(),['abyss_component_binding.lua','abyss_theme.lua']);
 assert.equal(readFileSync(join(root,'out/abyss_theme.lua'),'utf8'),'existing theme sentinel');
 console.log(`PASS: ${mode} component output -> ${source}; no input or existing output changed; no partial files`);passed++;
});
for(const mode of ['hardlink','symlink'])fixture(root=>{
 const backing=join(root,'generated-component.lua'),target=join(root,'out/abyss_component_binding.lua');writeFileSync(backing,'old output');(mode==='hardlink'?linkSync:symlinkSync)(backing,target);
 const result=spawnSync(process.execPath,['scripts/build-ui.mjs','out'],{cwd:root,encoding:'utf8'});
 assert.equal(result.status,0,result.stderr);assert.equal(readFileSync(backing,'utf8'),'-- Original-component comparison is opt-in.\nreturn {schemaVersion=1,enabled=false}\n');assert.deepEqual(readFileSync(target),readFileSync(backing));
 console.log(`PASS: legitimate ${mode} component output updated normally`);passed++;
});
console.log(JSON.stringify({passed,failed:0,node:process.version,platform:process.platform,repo}));
